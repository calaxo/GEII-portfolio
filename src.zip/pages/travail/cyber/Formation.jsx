const Formation = () => {
    return <div>Formation des employés</div>;
  };
  
  export default Formation;
  