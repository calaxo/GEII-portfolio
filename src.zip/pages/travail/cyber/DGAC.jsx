const DGAC = () => {
    return <div>develeopment web back</div>;
  };
  
  export default DGAC;
  