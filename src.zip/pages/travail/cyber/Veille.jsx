const Veille = () => {
    return <div>Veille info</div>;
  };
  
  export default Veille;
  