const Aero = () => {
    return <div>aeronautique</div>;
  };
  
  export default Aero;
  