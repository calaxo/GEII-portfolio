const Simu = () => {
    return <div>les simulateur</div>;
  };
  
  export default Simu;
  