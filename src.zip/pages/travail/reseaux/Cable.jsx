const Cable = () => {
    return <div>Cable management</div>;
  };
  
  export default Cable;
  