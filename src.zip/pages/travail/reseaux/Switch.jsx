const Switch = () => {
    return <div>Switch reseaux</div>;
  };
  
  export default Switch;
  