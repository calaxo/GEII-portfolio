const Firewall = () => {
    return <div>Firewall

        regle et tout
    </div>;
  };
  
  export default Firewall;
  