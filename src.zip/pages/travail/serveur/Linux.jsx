const Linux = () => {
    return <div>linux</div>;
  };
  
  export default Linux;
  