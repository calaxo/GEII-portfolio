const ADir = () => {
    return <div>AD
        droit
        admin
        etc
    </div>;
  };
  
  export default ADir;
  