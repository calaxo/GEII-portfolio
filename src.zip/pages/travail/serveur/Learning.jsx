const Learning = () => {
    return <div>Learning
moodle

    </div>;
  };
  
  export default Learning;
  