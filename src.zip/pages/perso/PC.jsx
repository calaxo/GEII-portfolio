import { HashRouter as Router, Routes, Route, NavLink, Navigate } from "react-router-dom";

const PC = () => {
  return (
    <div>
    Montage de PC
    </div>
  );
};

export default PC;
