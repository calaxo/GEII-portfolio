const Git = () => {
    return <div>develeopment avec git</div>;
  };
  
  export default Git;
  