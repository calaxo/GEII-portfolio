const Front = () => {
    return <div>develeopment web Front</div>;
  };
  
  export default Front;
  