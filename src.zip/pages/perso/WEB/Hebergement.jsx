const Hebergement = () => {
    return <div>Hebergement

o2switch

    </div>;
  };
  
  export default Hebergement;
  