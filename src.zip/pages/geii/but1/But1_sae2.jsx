const But1_sae2 = () => {
    return <div>Sonometre</div>;
  };
  
  export default But1_sae2;
  