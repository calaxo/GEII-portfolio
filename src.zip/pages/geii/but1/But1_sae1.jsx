const But1_sae1 = () => {
    return <div>verifier moteur</div>;
  };
  
  export default But1_sae1;
  