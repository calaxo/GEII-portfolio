const But1_sae3 = () => {
    return <div>trieur de dechet</div>;
  };
  
  export default But1_sae3;
  