const But2_sae1 = () => {
    return <div>stylo voltmetre avec fils</div>;
  };
  
  export default But2_sae1;
  