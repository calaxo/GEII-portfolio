const But2_sae2 = () => {
    return <div>stylo voltmetre sans fils</div>;


    
  };
  
  export default But2_sae2;
  


