const Condition = () => {
  return (
    <div>

        {/* <h2>Hébergeur</h2>
      <p>Nom de l'hébergeur: [Nom de l'hébergeur]</p>
      <p>Coordonnées de l'hébergeur: [Coordonnées de l'hébergeur]</p> */}
        <h1>Condition légales</h1>
        <h2>Webmaster</h2>
        site pensé et crée par Calendreau Axel

        certaine image on été créee par des inteligence artificielle
        
    </div>
  );
};

export default Condition;
