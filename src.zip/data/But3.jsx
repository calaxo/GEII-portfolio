

const data  = [
    { id: 1, tache: "dev", ressource: "description1", trace: "image1" , evaluation: "evaluation1" },
    { id: 2, tache: "base de donnée", ressource: "on a appris a faire des base de données",trace: "image1", evaluation: "evaluation1" },
    { id: 3, tache: "react", ressource: "comme je sais fair j'ai fait un site react",trace: "image1", evaluation: "evaluation1" },
  ];

export default data;