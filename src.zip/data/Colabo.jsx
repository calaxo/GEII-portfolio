const collaborateurs_But3 = [
    { nom: "NIVEAU", prenom: "Clément", lien: "https://bv.univ-poitiers.fr/access/content/user/cnivea01/portfolio/index.html" },
    { nom: "SOURIAU", prenom: "Thomas", lien: "https://bv.univ-poitiers.fr/access/content/user/tsouriau/portfolio/index.html" },
    { nom: "CREUZAU", prenom: "Kevin", lien: "https://bv.univ-poitiers.fr/access/content/user/kcreuzea/pflSAE5-6/Portfolio.html" },
    { nom: "CARRIER", prenom: "Amaury", lien: "https://bv.univ-poitiers.fr/access/content/user/acarri04/monportfolio/index.html" }
];

export default collaborateurs_But3;